const { ethers, upgrades } = require("hardhat")

/**  * 2025/02/15 in sepolia testnet
 * esVault contract deployed to: 0x606e887AC9F598BD526c52735CA8eAa34ce17D0f
     esVault ImplementationAddress: 0xD896BE78246BABAE19F3569A77a7c6704cb0Bc98
     esVault AdminAddress: 0x6c81556dD0D61077Cb04c43e879536D993b61aeA
   esDex contract deployed to: 0xBe2D4Bc7e5DC3677302B8c3C3521013f7bCc421c
      esDex ImplementationAddress: 0x26060bc1667E72B91c97e77EAc648D29558Bd268
      esDex AdminAddress: 0x6c81556dD0D61077Cb04c43e879536D993b61aeA
 */

async function main() {
  const [deployer] = await ethers.getSigners()
  console.log("deployer: ", deployer.address)

  //1.部署vault

  // let esVault = await ethers.getContractFactory("EasySwapVault")
  //可升级插件去部署
  // esVault = await upgrades.deployProxy(esVault, { initializer: 'initialize' });
  // await esVault.deployed()
  
  // 代理合约地址
  // console.log("esVault contract deployed to:", esVault.address) 
  // //0x606e887AC9F598BD526c52735CA8eAa34ce17D0f
  // 真身地址
  // console.log(await upgrades.erc1967.getImplementationAddress(esVault.address), " esVault getImplementationAddress")
  // //0xD896BE78246BABAE19F3569A77a7c6704cb0Bc98
  // 管理合约方法地址 
  // console.log(await upgrades.erc1967.getAdminAddress(esVault.address), " esVault getAdminAddress")
  // //0x6c81556dD0D61077Cb04c43e879536D993b61aeA


  //2.部署book 

  // newProtocolShare = 200;
  // newESVault = "0x606e887AC9F598BD526c52735CA8eAa34ce17D0f";
  // EIP712Name = "EasySwapOrderBook";
  // EIP712Version = "1";
  // let esDex = await ethers.getContractFactory("EasySwapOrderBook")
  // esDex = await upgrades.deployProxy(esDex, [newProtocolShare, newESVault, EIP712Name, EIP712Version], { initializer: 'initialize' });
  // await esDex.deployed()
  // console.log("esDex contract deployed to:", esDex.address)
  // //0xBe2D4Bc7e5DC3677302B8c3C3521013f7bCc421c
  // console.log(await upgrades.erc1967.getImplementationAddress(esDex.address), " esDex getImplementationAddress")
  // //0x26060bc1667E72B91c97e77EAc648D29558Bd268
  // console.log(await upgrades.erc1967.getAdminAddress(esDex.address), " esDex getAdminAddress")
  //  //0x6c81556dD0D61077Cb04c43e879536D993b61aeA



  //设置vault book 关系  
  // esDexAddress = "0xBe2D4Bc7e5DC3677302B8c3C3521013f7bCc421c"
  // esVaultAddress = "0x606e887AC9F598BD526c52735CA8eAa34ce17D0f"
  // const esVault = await (
  //   await ethers.getContractFactory("EasySwapVault")
  // ).attach(esVaultAddress)
  // tx = await esVault.setOrderBook(esDexAddress)
  // await tx.wait()
  // console.log("esVault setOrderBook tx:", tx.hash) 
  // //0x20debe63de8633308a5633783e087cf201c13759448bfac730fa87f2cbb77d51
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })
