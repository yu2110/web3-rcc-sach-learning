const { ethers, upgrades } = require("hardhat")

async function main() {

  // 总结  
  //  部署 nft 并且mint
  //env 地址 deployer
  const [deployer] = await ethers.getSigners()
  console.log("deployer: ", deployer.address)
  //部署合约到TestERC721 测试网    Troll --> TestERC721（hs
  // q add）
  // let TestERC721 = await ethers.getContractFactory("TestERC721")
  // const testERC721 = await TestERC721.deploy()
  // await testERC721.deployed()
  // console.log("testERC721 contract deployed to:", testERC721.address)

  //mint  testERC721Address 上一步部署的合约地址  Troll -> TestERC721 (hsq add)  50--->0  (hsq add )
  let testERC721Address = "0xf58D26ec4839F039cC9F52FA0EFA88289f2fe6F7";
  let testERC721 = await (await ethers.getContractFactory("TestERC721")).attach(testERC721Address)
  tx = await testERC721.mint(deployer.address, 0); 
  await tx.wait()
  console.log("mint tx:", tx.hash)//0xbcb7e560046d7ac215487e32c4884dc57a24a2a4d3f4f106b5389286a2652ca7
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })
