

INSERT INTO `ob_collection_sepolia` (`id`, `symbol`, `chain_id`, `auth`, `token_standard`, `name`, `creator`, `address`, `owner_amount`, `item_amount`, `description`, `website`, `twitter`, `discord`, `instagram`, `floor_price`, `sale_price`, `volume_total`, `image_uri`, `banner_uri`, `opensea_ban_scan`, `is_syncing`, `history_sale_sync`, `history_overview`, `floor_price_status`, `create_time`, `update_time`)
VALUES
	(1, 'Troll', 11155111, 0, 721, 'Troll', '0xC50078806fd0a417995Daf56cD8C5f764007B004', '0xBe2D4Bc7e5DC3677302B8c3C3521013f7bCc421c', 1, 50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, NULL, NULL);





INSERT INTO `ob_indexed_status` (`id`, `chain_id`, `last_indexed_block`, `last_indexed_time`, `index_type`, `create_time`, `update_time`)
VALUES
	(1, 11155111, 8316404, 1747118688, 6, NULL, NULL);

INSERT INTO `ob_indexed_status` (`id`, `chain_id`, `last_indexed_block`, `last_indexed_time`, `index_type`, `create_time`, `update_time`)
VALUES
	(2, 11155111, 8316404, 1747118688, 5, NULL, NULL);	



INSERT INTO `ob_item_sepolia` (`id`, `chain_id`, `token_id`, `name`, `owner`, `collection_address`, `creator`, `supply`, `list_price`, `list_time`, `sale_price`, `views`, `is_opensea_banned`, `create_time`, `update_time`)
VALUES
	(1, 11155111, '0', 'Troll', '0xC50078806fd0a417995Daf56cD8C5f764007B004', '0xBe2D4Bc7e5DC3677302B8c3C3521013f7bCc421c', '', 0, NULL, NULL, NULL, NULL, 0, NULL, NULL),
	(2, 11155111, '1', 'Troll', '0xC50078806fd0a417995Daf56cD8C5f764007B004', '0xBe2D4Bc7e5DC3677302B8c3C3521013f7bCc421c', '', 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
