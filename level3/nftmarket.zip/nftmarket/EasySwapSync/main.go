package main

import (
	"github.com/ProjectsTask/EasySwapSync/cmd"
)

func main() {
	cmd.Execute()
}
