## Getting Started

```bash
npm i -g pnpm

pnpm i

pnpm dev

```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.
