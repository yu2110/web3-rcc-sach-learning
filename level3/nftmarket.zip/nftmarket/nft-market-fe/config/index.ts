
export const LOCALE_COOKIE_NAME = 'locale'
