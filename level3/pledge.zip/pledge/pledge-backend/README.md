# pledge-backend


 //可能需要vpn全局代理和 go的镜像，source ~/.bash_profile,curl ipinfo.io
 go env -w GO111MODULE=on
 go env -w GOPROXY=https://goproxy.cn,direct

 go mod tidy //装项目所需的依赖





The project is divided into two parts, one is API and the other is scheduled task

API

    cd api
    go run pledge_api.go

pool task

    cd schedule
    go run pledge_task.go

===============
入口文件 pledge_api.go    pledge_task.go

使用go gin框架 

=========
预言机，是一种为区块链获得链外数据的机制、协议，包括获取其他区块链的数据以及传统互联网的数据。

