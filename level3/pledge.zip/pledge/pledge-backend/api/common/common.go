package common

import (
	"pledge-backend/config"
)

var Config *config.Conf
