package response

type Login struct {
	TokenId string `json:"token_id"`
}
