/**
 * @ Author: Muniz
 * @ Create Time: 2020-06-12 14:02:48
 * @ Modified by: Muniz
 * @ Modified time: 2020-07-22 19:27:31
 * @ Description: 英文文案
 */

const enUS = {
  translation: {
    Language: 'Language',
    zhCN: 'Chinese',
    enUS: 'English',
  },
  home: {
    title: 'React PC development template',
    technology: 'Technology stack:',
  },
};
export default enUS;
