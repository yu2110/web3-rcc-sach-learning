import React from 'react';
import './index.less';

const Footer = () => {
  return <div className="components_footer"></div>;
};

export default Footer;
