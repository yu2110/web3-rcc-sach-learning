import TransactionConfirmationModal from './TransactionConfirmationModal'

export { default as ConfirmationModalContent } from './ConfirmationModalContent'
export { default as ConfirmationPendingContent } from './ConfirmationPendingContent'
export { default as TransactionErrorContent } from './TransactionErrorContent'
export { default as TransactionSubmittedContent } from './TransactionSubmittedContent'

export default TransactionConfirmationModal
