// export const DEFAULT_TOKEN_LIST_URL = 'https://pledge.rcc-tec.xyz/api/v21/token?chainId=97'

// export const DEFAULT_LIST_OF_LISTS: string[] = [
//   "https://pledge.rcc-tec.xyz/api/v21/token?chainId=97",
// "https://pledge.rcc-tec.xyz/api/v21/token?chainId=56"
// ]

export const DEFAULT_TOKEN_LIST_URL = 'https://pledge.rcc-tec.xyz/api/v22/token?chainId=97';

export const DEFAULT_LIST_OF_LISTS: string[] = [
  'https://pledge.rcc-tec.xyz/api/v22/token?chainId=97',
  'https://pledge.rcc-tec.xyz/api/v22/token?chainId=56',
];
